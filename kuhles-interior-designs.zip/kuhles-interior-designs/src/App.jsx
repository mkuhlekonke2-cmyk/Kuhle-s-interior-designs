export default function App() {
  const services = [
    {
      title: "Luxury Interior Styling",
      description:
        "Sophisticated interior concepts crafted with elegance, comfort and timeless luxury.",
    },
    {
      title: "Designer Wardrobes",
      description:
        "Premium custom wardrobes designed to maximise beauty, storage and modern living.",
    },
    {
      title: "Gold Accent Finishes",
      description:
        "Elegant gold detailing and high-end finishes that elevate every space.",
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <section className="bg-gradient-to-br from-black via-neutral-950 to-yellow-950 px-6 py-24">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Kuhle's Interior Designs
            </h1>

            <p className="text-lg text-gray-300 mb-8">
              Luxury interiors inspired by modern elegance, black-and-gold aesthetics,
              and premium craftsmanship.
            </p>

            <button className="bg-yellow-500 text-black px-6 py-3 rounded-2xl font-semibold">
              View Projects
            </button>
          </div>

          <div className="bg-neutral-900 border border-yellow-700 rounded-3xl p-10">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-yellow-700 to-yellow-500 rounded-2xl h-40"></div>
              <div className="bg-gradient-to-br from-black to-yellow-800 rounded-2xl h-40"></div>
              <div className="bg-gradient-to-br from-yellow-900 to-black rounded-2xl h-40"></div>
              <div className="bg-gradient-to-br from-yellow-700 to-yellow-500 rounded-2xl h-40"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 py-20 bg-neutral-950">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Our Services</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-neutral-900 border border-yellow-700 rounded-3xl p-8 shadow-2xl"
              >
                <div className="w-14 h-14 rounded-2xl bg-yellow-500 mb-6"></div>

                <h3 className="text-2xl font-semibold mb-4">
                  {service.title}
                </h3>

                <p className="text-gray-300">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
